package org.firstinspires.ftc.teamcode.Competition_Code.Utilities
data class PIDParams(val kp: Double, val ki: Double, val kd: Double, val kf: Double = 0.0)

