package org.firstinspires.ftc.teamcode.Competition_Code.Subsystems

class CameraGlobals {
    companion object{
        lateinit var color :GlobalState
    }

    enum class GlobalState{
        Blue, Red
    }


}